package com.springboot.rocks.tools.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {

	@GetMapping({ "/", "/dashboard" })
	String homepage() {
		return "dashboard";
	}

	@GetMapping("/cascade")
	String cascadepage() {
		return "cascade";
	}
	
	@GetMapping("/jsontohtml")
	String jsontohtmlpage() {
		return "jsontohtmlJustTab_option2";
	}
	
	

}
