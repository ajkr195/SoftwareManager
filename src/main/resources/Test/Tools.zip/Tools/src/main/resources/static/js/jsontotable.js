const json='[{"Book ID":"1","Book Name":"Computer Architecture","Category":"Computers","Price":"125.60"},{"Book ID":"2","Book Name":"Asp.Net 4 Blue Book","Category":"Programming","Price":"56.00"},{"Book ID":"3","Book Name":"Popular Science","Category":"Science","Price":"210.40"}]';

// Cache the button, and add an event listener to
// it which calls the API (returns data after two seconds)
const button = document.querySelector('button');
button.addEventListener('click', fetchData, false);

// Mock API
function mockApi() {
  return new Promise(res => {
    setTimeout(() => res(json), 2000);
  });
}

// Calls the API, parses the json, then
// calls createTable with the data
function fetchData() {
  button.textContent = 'Loading...';
  button.disabled = true;
  mockApi()
    .then(res => JSON.parse(res))
    .then(createTable);
}

// `map` over the keys of first object
// in the array, and return a string of HTML
function getColumnHeadings(data) {
  return Object.keys(data[0]).map(key => {
    return `<td>${key}</td>`;
  }).join('');
}

// `map` over each object in the array,
// and return a string of HTML. It calls
// `getCells` on each object
function getRows(data) {
  return data.map(obj => {
    return `<tr>${getCells(obj)}</tr>`
  }).join('');
}

// `map` over the values of an object
// and return a string of HTML
function getCells(obj) {
  return Object.values(obj).map(value => {
    return `<td>${value}</td>`;
  }).join('');
}

function createTable(data) {
  
  // Get the headings, and the rows
  const headings = getColumnHeadings(data);
  const rows = getRows(data);

  // Create an HTML string
  const html = `
    <table>
      <tbody>
        <tr class="headings">${headings}</tr>
        ${rows}
      </tbody>
    </table>
  `

  // Add the string to the DOM
  document.body.insertAdjacentHTML('beforeend', html);

}