(() => {
	'use strict'
	const ctx = document.getElementById('myChart');
	new Chart(ctx, {
		type: 'bar',
		data: {
			labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange', 'gray'],
			datasets: [{
				label: '# of Votes',
				data: [12, 19, 6, 13, 2, 9, 15],
				borderWidth: 3
			}]
		},
		options: {
			scales: {
				y: {
					beginAtZero: true
				}
			}
		}
	});
})()
