package com.springboot.rocks.tools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToolsApplicationTests {

	@Test
	void contextLoads() {
	}

}
